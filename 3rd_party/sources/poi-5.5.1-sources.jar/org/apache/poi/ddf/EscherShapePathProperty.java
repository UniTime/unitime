/* ====================================================================
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
==================================================================== */

package org.apache.poi.ddf;

/**
 * Defines the constants for the various possible shape paths.
 */
public class EscherShapePathProperty extends EscherSimpleProperty {

    public static final int LINE_OF_STRAIGHT_SEGMENTS = 0;
    public static final int CLOSED_POLYGON = 1;
    public static final int CURVES = 2;
    public static final int CLOSED_CURVES = 3;
    public static final int COMPLEX = 4;

    /**
     * Create an instance of an escher shape path property.
     *
     * @param propertyNumber which property to handle
     * @param shapePath which shape path to handle
     */
    public EscherShapePathProperty( short propertyNumber, int shapePath ) {
        super( propertyNumber, false, false, shapePath );
    }

    public EscherShapePathProperty( EscherPropertyTypes type, int shapePath ) {
        super( type, false, false, shapePath );
    }
}
