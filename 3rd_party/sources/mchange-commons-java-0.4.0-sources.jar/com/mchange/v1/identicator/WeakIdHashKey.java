package com.mchange.v1.identicator;

import java.lang.ref.*;

// revisit equals() if ever made non-final

final class WeakIdHashKey extends IdHashKey
{
    Ref keyRef;
    int hash;

    public WeakIdHashKey(Object keyObj, Identicator id, ReferenceQueue rq)
    {
	super( id );

	if (keyObj == null)
	    throw new UnsupportedOperationException("Collection does not accept nulls!");

	this.keyRef = new Ref( keyObj, rq );
	this.hash = id.hash( keyObj );
    }

    public Ref getInternalRef()
    { return this.keyRef; }

    public Object getKeyObj()
    { return keyRef.get(); }

    public boolean equals(Object o)
    {
	// fast type-exact match for final class
	if (o instanceof WeakIdHashKey)
	    {
		WeakIdHashKey other = (WeakIdHashKey) o;
		if (this.keyRef == other.keyRef)
		    return true;
		else
		    {
			Object myKeyObj = this.keyRef.get();
			Object oKeyObj  = other.keyRef.get();
			if (myKeyObj == null || oKeyObj == null)
			    return false;
			else
			    return id.identical( myKeyObj, oKeyObj );
		    }
	    }
	else
	    return false;
    }

    public int hashCode()
    { return hash; }

    class Ref extends WeakReference
    {
	public Ref( Object referant, ReferenceQueue rq )
	{ super( referant, rq ); }
	
	WeakIdHashKey getKey()
	{ return WeakIdHashKey.this; }
    }
}
