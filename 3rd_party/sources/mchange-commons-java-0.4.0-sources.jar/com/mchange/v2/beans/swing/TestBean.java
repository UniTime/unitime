package com.mchange.v2.beans.swing;

import java.beans.*;

public class TestBean
{
    String s;
    int    i;
    float  f;

    PropertyChangeSupport pcs = new PropertyChangeSupport( this );

    public String getTheString()
    { return s; }

    public int getTheInt()
    { return i; }

    public float getTheFloat()
    { return f; }

    public void setTheString( String new_s )
    {
	if (! eqOrBothNull( new_s, s ) )
	    {
		String old_s = s;
		this.s = new_s;
		pcs.firePropertyChange( "theString", old_s, s );
	    }
    }

    public void setTheInt( int new_i )
    {
	if ( new_i != i )
	    {
		int old_i = i;
		i = new_i;
		pcs.firePropertyChange( "theInt", old_i, i );
	    }
    }

    public void setTheFloat( float new_f )
    {
	if ( new_f != f )
	    {
		float old_f = f;
		f = new_f;
		pcs.firePropertyChange( "theFloat", Float.valueOf(old_f), Float.valueOf(f) );
	    }
    }

    public void addPropertyChangeListener( PropertyChangeListener pcl )
    { pcs.addPropertyChangeListener( pcl ); }
    
    public void removePropertyChangeListener( PropertyChangeListener pcl )
    { pcs.removePropertyChangeListener( pcl ); }

    private boolean eqOrBothNull( Object a, Object b )
    {
	return
	    a == b ||
	    (a != null && a.equals(b));
    }
}

