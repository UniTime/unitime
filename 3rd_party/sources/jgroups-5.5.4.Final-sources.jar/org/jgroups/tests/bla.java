package org.jgroups.tests;

import org.jgroups.Global;
import org.jgroups.annotations.LocalAddress;
import org.jgroups.annotations.Property;

import java.net.InetAddress;

/**
 * @author Bela Ban
 * @since x.y
 */
public class bla {

    protected class Transport {
        @LocalAddress
        @Property(name="bind_addr",
          description="The bind address which should be used by this transport. The following special values " +
            "are also recognized: GLOBAL, SITE_LOCAL, LINK_LOCAL, NON_LOOPBACK, match-interface, match-host, match-address",
          defaultValueIPv4=Global.NON_LOOPBACK_ADDRESS, defaultValueIPv6=Global.NON_LOOPBACK_ADDRESS,
          systemProperty={Global.BIND_ADDR},writable=false)
        protected InetAddress bind_addr;
        @Property(description="If true, create virtual threads, otherwise create native threads")
        protected boolean use_vthreads=true;

        public boolean useVirtualThreads() {
            return use_vthreads;
        }

        public Transport useVirtualThreads(boolean vt) {
            this.use_vthreads=vt;
            return this;
        }

        @Override
        public String toString() {
            return String.format("bind_addr=%s, use_vthreads=%b", bind_addr, use_vthreads);
        }
    }

    protected void start() throws Exception {
        Transport tp=new Transport();
        System.out.println("tp = " + tp);


    }



    public static void main(String[] args) throws Exception {
        new bla().start();
    }
}
