package com.mchange.v2.c3p0.subst;

public final class C3P0Substitutions
{
    public final static String VERSION    = "0.12.0";
    public final static String DEBUG      = "true";
    public final static String TRACE      = "10";
    public final static String TIMESTAMP  = "2026-02-22T16:57:43.223248Z";

    private C3P0Substitutions()
    {}
}
